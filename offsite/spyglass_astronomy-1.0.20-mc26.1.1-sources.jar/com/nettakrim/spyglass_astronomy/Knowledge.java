package com.nettakrim.spyglass_astronomy;

import java.util.ArrayList;

import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Component;

public class Knowledge {
    public enum Level {
        NOVICE,
        ADEPT,
        EXPERT,
        MASTER
    }

    private Level starKnowledge;
    private Level orbitKnowledge;
    private boolean bypass;
    private int planets;
    private int comets;

    public void updateStarKnowledge(ArrayList<Constellation> constellations, ArrayList<Star> stars) {
        int namedStars = 0;
        for (Star star : stars) {
            if (!star.isUnnamed()) {
                namedStars++;
            }
        }
        if (constellations.size() >= 20 && namedStars >= 8) {
            starKnowledge = Level.MASTER;
            return;
        }
        if (constellations.size() >= 10 && namedStars >= 3) {
            starKnowledge = Level.EXPERT;
            return;
        }
        if (constellations.size() >= 5) {
            starKnowledge = Level.ADEPT;
            return;
        }
        starKnowledge = Level.NOVICE;
    }

    public MutableComponent getInstructionsToStarKnowledgeStage(int stage) {
        return switch (stage) {
            case 1 -> Component.translatable(SpyglassAstronomyClient.MODID + ".commands.info.starknowledge.toadept", "5");
            case 2 -> Component.translatable(SpyglassAstronomyClient.MODID + ".commands.info.starknowledge.toexpert", "10", "3");
            case 3 -> Component.translatable(SpyglassAstronomyClient.MODID + ".commands.info.starknowledge.tomaster", "20", "8");
            default -> Component.empty();
        };
    }

    public void updateOrbitKnowledge(ArrayList<OrbitingBody> orbitingBodies, int planets, int comets) {
        int namedPlanets = 0;
        int namedComets = 0;
        this.planets = planets;
        this.comets = comets;
        for (OrbitingBody orbitingBody : orbitingBodies) {
            if (!orbitingBody.isUnnamed()) {
                if (orbitingBody.isPlanet) namedPlanets++;
                else namedComets++;
            }
        }
        if (namedPlanets >= planets-1 && namedComets >= comets-1) {
            orbitKnowledge = Level.MASTER;
            return;
        }
        if (namedPlanets >= planets/3*2 && namedComets >= 2) {
            orbitKnowledge = Level.EXPERT;
            return;
        }
        if (namedPlanets >= planets/3 || namedComets >= 1) {
            orbitKnowledge = Level.ADEPT;
            return;
        }
        orbitKnowledge = Level.NOVICE;
    }

    public MutableComponent getInstructionsToOrbitKnowledgeStage(int stage) {
        return switch (stage) {
            case 1 -> Component.translatable(SpyglassAstronomyClient.MODID + ".commands.info.orbitknowledge.toadept", Integer.toString(planets / 3), "1");
            case 2 -> Component.translatable(SpyglassAstronomyClient.MODID + ".commands.info.orbitknowledge.toexpert", Integer.toString(planets / 3 * 2), "2");
            case 3 -> Component.translatable(SpyglassAstronomyClient.MODID + ".commands.info.orbitknowledge.tomaster", Integer.toString(planets - 1), Integer.toString(comets - 1));
            default -> Component.empty();
        };
    }

    private void updateFlags(Level level, int[] flags, int index) {
        int current = switch (level) {
            case NOVICE -> 0;
            case ADEPT -> 1;
            case EXPERT -> 2;
            case MASTER -> 3;
        };
        if (flags[index] == -1) flags[index] = current;
        else flags[index] = Math.min(flags[index], current);
    }

    public Component getKnowledgeInstructions(int[] flags) {
        return getInstructionsToStarKnowledgeStage(flags[0]).append(getInstructionsToOrbitKnowledgeStage(flags[1]));
    }

    public boolean starKnowledgeAtleast(Level level, int[] flags) {
        boolean isAtleast = bypass || knowledgeAtleast(starKnowledge, level);
        if (!isAtleast) {
            updateFlags(level, flags, 0);
        }
        return isAtleast;
    }

    public boolean orbitKnowledgeAtleast(Level level, int[] flags) {
        boolean isAtleast = bypass || knowledgeAtleast(orbitKnowledge, level);
        if (!isAtleast) {
            updateFlags(level, flags, 1);
        }
        return isAtleast;
    }

    private boolean knowledgeAtleast(Level a, Level b) {
        //b <= a 
        if (b == a) return true;
        if (a == Level.MASTER) return true;
        if (b == Level.NOVICE) return true;
        return a == Level.EXPERT && b == Level.ADEPT;
    }

    public boolean bypassKnowledge() {
        bypass = !bypass;
        return bypass;
    }
}
